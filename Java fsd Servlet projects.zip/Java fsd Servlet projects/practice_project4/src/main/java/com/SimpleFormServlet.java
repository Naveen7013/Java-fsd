package com;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/SimpleFormServlet")
public class SimpleFormServlet implements jakarta.servlet.Servlet {
    
    private ServletConfig config;

    public void init(ServletConfig config) {
        this.config = config;
        System.out.println("Initialization complete");
    }

    public void service(ServletRequest req, ServletResponse res) throws IOException, ServletException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        out.println("<html>");
        out.println("<body>");
        out.println("<h2>Simple Form Submission</h2>");

        // Handle form submission
        if (req.getParameter("submit") != null) {
            String firstName = req.getParameter("firstName");
            String lastName = req.getParameter("lastName");

            out.println("<p>Thank you for submitting the form!</p>");
            out.println("<p>First Name: " + firstName + "</p>");
            out.println("<p>Last Name: " + lastName + "</p>");
        } else {
            // Display the form
            out.println("<form method='post' action='SimpleFormServlet'>");
            out.println("First Name: <input type='text' name='firstName'><br>");
            out.println("Last Name: <input type='text' name='lastName'><br>");
            out.println("<input type='submit' name='submit' value='Submit'>");
            out.println("</form>");
        }

        out.println("</body>");
        out.println("</html>");
    }

    public void destroy() {
        System.out.println("In destroy() method");
    }

    public ServletConfig getServletConfig() {
        return config;
    }

    public String getServletInfo() {
        return "This is a simple form servlet";
    }
}
