package com;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/FeedbackServlet")
public class NameServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public NameServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handling GET requests is optional in this example
        // You can customize it based on your requirements
        response.getWriter().append("This servlet only handles POST requests for feedback submission.");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String feedback = request.getParameter("feedback");

        PrintWriter out = response.getWriter();
        out.println("<html><body>");

        if (name != null && feedback != null && !name.isEmpty() && !feedback.isEmpty()) {
            out.println("Thank you, " + name + ", for your valuable feedback:<br>");
            out.println("<em>" + feedback + "</em>");
        } else {
            out.println("Feedback submission failed. Please provide both your name and feedback.");
        }

        out.println("</body></html>");
    }
}
