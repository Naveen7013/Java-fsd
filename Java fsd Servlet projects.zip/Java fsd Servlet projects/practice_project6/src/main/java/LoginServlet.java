import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if userid parameter is present
        String userIdParam = request.getParameter("userid");
        if (userIdParam != null && !userIdParam.isEmpty()) {
            Cookie userId = new Cookie("userid", userIdParam);
            response.addCookie(userId);
            response.sendRedirect("dashboard");
        } else {
            // Handle the case where userid parameter is missing
            response.getWriter().write("Error: User ID parameter is missing");
            // You might want to redirect to an error page or provide a link to go back to the login page
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Call doGet to handle both GET and POST requests
        doGet(request, response);
    }
}
