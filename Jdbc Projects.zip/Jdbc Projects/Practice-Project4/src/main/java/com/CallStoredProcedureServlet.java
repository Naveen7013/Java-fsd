package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class CallStoredProcedureServlet
 */
public class CallStoredProcedureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "AaBb@12345678";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
//    public CallStoredProcedureServlet() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		callStoredProcedure(response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	 private void callStoredProcedure(HttpServletResponse response) throws IOException {
	        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
	            // Prepare the stored procedure call
	            String storedProcedureCall = "{call InsertProduct(?, ?)}";
	            try (PreparedStatement statement = connection.prepareCall(storedProcedureCall)) {
	                // Set the parameters
	                statement.setString(1, "New Product");
	                statement.setDouble(2, 49.99);

	                // Execute the stored procedure
	                statement.execute();

	                // Display success message
	                PrintWriter out = response.getWriter();
	                out.println("<html><head><title>Stored Procedure</title></head><body>");
	                out.println("<h2>Stored Procedure Called Successfully</h2>");
	                out.println("<a href=\"index.html\">Back to Home</a>");
	                out.println("</body></html>");
	            } catch (SQLException e) {
	                e.printStackTrace();
	                response.getWriter().println("Error calling stored procedure: " + e.getMessage());
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            response.getWriter().println("Error establishing database connection: " + e.getMessage());
	        }
	    }

}
