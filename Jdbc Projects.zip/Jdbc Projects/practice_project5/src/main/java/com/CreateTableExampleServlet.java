package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/CreateTableExampleServlet")
public class CreateTableExampleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String jdbcUrl = "jdbc:mysql://localhost:3306/books";
        String username = "root";
        String password = "Naveen701@";

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Define the SQL statement to create a table
            String createTableSQL = "CREATE TABLE IF NOT EXISTS product ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT,"
                    + "name VARCHAR(255) NOT NULL,"
                    + "ITEM VARCHAR(255))";

            // Execute the SQL statement to create the table
            statement.executeUpdate(createTableSQL);

            // Now, let's add SELECT logic to retrieve and display data

            // Define the SQL statement to select data from the table
            String selectDataSQL = "SELECT * FROM product";

            // Execute the SQL statement to select data
            ResultSet resultSet = statement.executeQuery(selectDataSQL);

            // Display the selected data
            PrintWriter out = response.getWriter();
            out.println("Table created successfully! <br>");
            out.println("<h2>Selected Data:</h2>");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String item = resultSet.getString("ITEM");

                out.println("ID: " + id + ", Name: " + name + ", Item: " + item + "<br>");
            }

            // Add DROP logic to drop the table

            // Define the SQL statement to drop the table
            String dropTableSQL = "DROP TABLE IF EXISTS product";

            // Execute the SQL statement to drop the table
            statement.executeUpdate(dropTableSQL);

            out.println("<br>Table dropped successfully!");

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
