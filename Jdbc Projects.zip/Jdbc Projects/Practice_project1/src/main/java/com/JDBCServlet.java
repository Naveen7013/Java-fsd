package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/JDBCServlet")
public class JDBCServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/sampledb";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Naveen701@";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            // Insert data into the database
            insertData(connection, "john_doe", "password123");

            // Retrieve and display data from the database
            displayData(connection, out);

        } catch (SQLException e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }

    private void insertData(Connection connection, String username, String password) throws SQLException {
        String insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
            insertStatement.setString(1, username);
            insertStatement.setString(2, password);
            insertStatement.executeUpdate();
        }
    }

    private void displayData(Connection connection, PrintWriter out) throws SQLException {
        String selectQuery = "SELECT * FROM users";
        try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
             ResultSet resultSet = selectStatement.executeQuery()) {

            // Display retrieved data
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String usernameResult = resultSet.getString("username");
                String passwordResult = resultSet.getString("password");
                out.println("ID: " + id + ", Username: " + usernameResult + ", Password: " + passwordResult + "<br>");
            }
        }
    }
}
