package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/JDBCDemoServlet")
public class JDBCDemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // JDBC Connection parameters
            String jdbcUrl = "jdbc:mysql://localhost:3306/books";
            String username = "root";
            String password = "Naveen701@";

            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute a simple SQL query
            String sqlQuery = "SELECT * FROM food";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Display the results
            out.println("<html><body>");
            out.println("<h2>Product List</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Item</th></tr>");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String item = resultSet.getString("ITEM");

                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + item + "</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            // Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
