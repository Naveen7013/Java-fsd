import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Register() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String action = request.getParameter("action");
        if ("register".equals(action)) {
            registerUser(request, out);
        } else if ("delete".equals(action)) {
            deleteUser(request, out);
        } else if ("update".equals(action)) {
            updateUser(request, out);
        }
    }

    private void registerUser(HttpServletRequest request, PrintWriter out) {
        String name = request.getParameter("name");
        String fname = request.getParameter("fname");
        String address = request.getParameter("address");
        String country = request.getParameter("country");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/register", "root", "Naveen701@");

            PreparedStatement ps = con.prepareStatement("INSERT INTO register VALUES(?,?,?,?)");

            ps.setString(1, name);
            ps.setString(2, fname);
            ps.setString(3, address);
            ps.setString(4, country);
            int i = ps.executeUpdate();

            if (i > 0) {
                out.print("You are successfully registered");
            }

            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void deleteUser(HttpServletRequest request, PrintWriter out) {
        String nameToDelete = request.getParameter("nameToDelete");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/register", "root", "Naveen701@");

            PreparedStatement ps = con.prepareStatement("DELETE FROM register WHERE name=?");
            ps.setString(1, nameToDelete);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.print("User deleted successfully");
            } else {
                out.print("User not found or deletion failed");
            }

            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }

    private void updateUser(HttpServletRequest request, PrintWriter out) {
        String nameToUpdate = request.getParameter("nameToUpdate");
        String updatedName = request.getParameter("updatedName");
        String updatedFname = request.getParameter("updatedFname");
        String updatedAddress = request.getParameter("updatedAddress");
        String updatedCountry = request.getParameter("updatedCountry");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/register", "root", "Naveen701@");

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE register SET name=?, fname=?, address=?, country=? WHERE name=?");

            ps.setString(1, updatedName);
            ps.setString(2, updatedFname);
            ps.setString(3, updatedAddress);
            ps.setString(4, updatedCountry);
            ps.setString(5, nameToUpdate);

            int i = ps.executeUpdate();

            if (i > 0) {
                out.print("User updated successfully");
            } else {
                out.print("User not found or update failed");
            }

            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
    }
}
