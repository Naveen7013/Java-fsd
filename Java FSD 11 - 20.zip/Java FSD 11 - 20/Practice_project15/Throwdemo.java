package Throwfinalkeyword;
public class Throwdemo
    {
        public static void main(String[] args)
        {
        	int n1=17;
        	try
            {
                if(n1==17)        
                    throw(new ArithmeticException("not eligible to vote"));
                else
                {
                    System.out.print("Eligible to vote");
                }
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }

            System.out.print("\n\tEnd of program.");
        }
    }
