package Throwfinalkeyword;
public class throw2 {

    public static void performOperation(int x) 
    		throws CustomException {
        if (x == 4 ) {
            throw new CustomException("It's my favourite number");
        } 
        else 
        {
            System.out.println("display my fav value: " + x);
        }
    }

    public static void main(String[] args) {
        throw2 demo = new throw2();

        try {
            demo.performOperation(4);
        } catch (CustomException ex) {
            System.out.println("Error: " + ex.getMessage());
        }

        System.out.println("End of program.");
    }
}

class CustomException extends Exception {
 public CustomException(String message) {
        super(message);
 }
}
