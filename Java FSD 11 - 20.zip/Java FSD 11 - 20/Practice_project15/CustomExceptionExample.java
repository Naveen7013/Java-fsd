package Throwfinalkeyword;
class CustomValidationException extends Exception {
    public CustomValidationException(String message) {
        super(message);
    }
}

public class CustomExceptionExample {
    public static void main(String[] args) {
        try {
            validateInput("invalidData");
        } catch (CustomValidationException ex) {
            System.out.println("Caught");
            System.out.println(ex.getMessage());
        }
    }

    static void validateInput(String data) throws CustomValidationException {
        if ("invalidData".equals(data)) {
            throw new CustomValidationException("Invalid data detected");
        } else {
            System.out.println("Input is valid: " + data);
        }
    }
}
