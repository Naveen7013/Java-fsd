package Throwfinalkeyword;
public class finalkeyword {

    public static void main(String[] args) {
        int[] num = { 1, 2, 3, 4, 5 };
        int index = 4;

        try {
            int result = num[index];
            System.out.println("Value at index " + index + ": " + result);
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Error: " + ex.getMessage());
        } finally {
            System.out.println("Finally block executed regardless of exception.");
        }
    }
}
