package Abstract;
abstract class Animal {
    String name;
    int age;

    public Animal(String name, int age) {
        System.out.println("Animal constructor called");
        this.name = name;
        this.age = age;
    }

    abstract void makeSound();

    @Override
    public String toString() {
        return "Name: " + name + "\nAge: " + age;
    }
}

class Dog extends Animal {
    String breed;

    public Dog(String name, int age, String breed) {
        super(name, age);
        System.out.println("Dog constructor called");
        this.breed = breed;
    }

    @Override
    void makeSound() {
        System.out.println("Woof! Woof!");
    }

    @Override
    public String toString() {
        return super.toString() + "\nBreed: " + breed;
    }
}

class Cat extends Animal {
    boolean isStray;

    public Cat(String name, int age, boolean isStray) {
        super(name, age);
        System.out.println("Cat constructor called");
        this.isStray = isStray;
    }

    @Override
    void makeSound() {
        System.out.println("Meow!");
    }

    @Override
    public String toString() {
        return super.toString() + "\nIs Stray: " + isStray;
    }
}

public class TestAnimals {
    public static void main(String[] args) {
        Animal animal1 = new Dog("rhyme", 3, "hohho");
        Animal animal2 = new Cat("scoopy", 2, true);

        System.out.println(animal1.toString());
        animal1.makeSound();

        System.out.println("\n" + animal2.toString());
        animal2.makeSound();
    }
}
