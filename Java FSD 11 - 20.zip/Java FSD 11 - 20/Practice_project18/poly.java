package polymorphism;


class multiplication 
{
    public int multiplication(int x, int y) 
    { 
        return (x * y); 
    } 
    public int multiplication(int x, int y, int z) 
    { 
        return (x * y * z); 
    } 
    public double sub(double x, double y) 
    { 
        return (x - y); 
    } 
    public static void main(String args[]) 
    { 
        multiplication m1 = new multiplication(); 
        System.out.println(m1.multiplication(5, 12)); 
        System.out.println(m1.multiplication(5, 10, 7)); 
        System.out.println(m1.sub(100.5, 25.5)); 
    } 
}
