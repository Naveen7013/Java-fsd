package inheritance;
class Vehicle {
    private String brand;
    private int year;

    public Vehicle(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }

    public String getBrand() {
        return brand;
    }

    public int getYear() {
        return year;
    }

    public void start() {
        System.out.println("The vehicle is starting.");
    }

    @Override
    public String toString() {
        return "Brand: " + brand + "\nYear: " + year;
    }
}

class Car extends Vehicle {
    private int numberOfDoors;

    public Car(String brand, int year, int numberOfDoors) {
        super(brand, year);
        this.numberOfDoors = numberOfDoors;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void accelerate() {
        System.out.println("The car is accelerating.");
    }

    @Override
    public String toString() {
        return super.toString() + "\nNumber of Doors: " + numberOfDoors;
    }
}

public class TestInheritance {
    public static void main(String[] args) {
        Car myCar = new Car("audi", 2018, 4);
        System.out.println(myCar.toString());

        myCar.start();
        myCar.accelerate();
    }
}
