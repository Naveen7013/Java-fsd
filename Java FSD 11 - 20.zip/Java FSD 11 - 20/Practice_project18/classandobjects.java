package classobjects;

public class ipl{
	String name;
	String city;
	int jersey;
	public ipl(String name,String city,int jersey)
	{
		this.name = name;
		this.city = city;
		this.jersey = jersey;
		
	}
    public String getName() 
    { 
        return name; 
    } 
    public String getcity() 
    { 
        return city; 
    } 
    public int getjersey() 
    { 
        return jersey; 
    }
	@Override
	public String toString() {
		return "ipl [name = " + name + ", city = " + city + ", jersey = " + jersey + "]";
	}
	public static void main(String[] args) 
    { 
        ipl i1 = new ipl("chennaisuperkings","Chennai",7); 
        System.out.println(i1.toString()); 
    } 
}


	
	
	



