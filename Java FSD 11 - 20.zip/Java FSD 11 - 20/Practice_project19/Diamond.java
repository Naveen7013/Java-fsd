package Diam;
interface RoyalEnfield 
{  
    default void info() 
    { 
        System.out.println("Here is your RoyalEnfield bike info"); 
    } 
} 
interface jawa 
{  
    default void info() 
    { 
        System.out.println("Here is your jawa info"); 
    } 
}  
public class TestClass implements RoyalEnfield, jawa 
{  
    public void show() 
    {  
        RoyalEnfield.super.info(); 
        jawa.super.info(); 
    } 
    @Override
	public void info() {
		// TODO Auto-generated method stub
		jawa.super.info();
	}
	public static void main(String args[]) 
    { 
        TestClass ob = new TestClass(); 
        ob.show(); 
    } 
}
