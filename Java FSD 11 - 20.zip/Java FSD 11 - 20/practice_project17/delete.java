package filehandling;
import java.io.IOException; 
import java.nio.file.*; 
  
public class delete 
{ 
    public static void main(String[] args) 
    { 
        try
        { 
            Files.deleteIfExists(Paths.get("C:\\Users\\naveen kumar\\Pictures\\delete")); 
        }  
        catch(DirectoryNotEmptyException e) 
        { 
            System.out.println("Empty directory."); 
        } 
        catch(IOException e) 
        { 
            System.out.println("Invalid permissions."); 
        } 
          
        System.out.println("Deletion successful."); 
    } 
}
