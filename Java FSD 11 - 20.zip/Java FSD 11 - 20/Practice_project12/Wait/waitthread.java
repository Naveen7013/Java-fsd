package Wait;

class waitthread {
    public static void main(String[] args) {
        final Object lock = new Object();

        Thread thread1 = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 1: India");
                try {
                    lock.wait();
                } 
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Thread 1: Austrila");
            }
        });

        Thread thread2 = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 2: Newzealand");
                lock.notify();
                System.out.println("Thread 2: SriLanka");
            }
        });

        thread1.start();
        thread2.start();
    }
}
