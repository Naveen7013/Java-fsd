package Sleep;

class BicycleSpeed extends Thread {

	@Override
	public void run() {
		for(int i = 0;i<=6;i++) {
			try{Thread.sleep(5000);
			}
			catch(InterruptedException e){
				System.out.println(e);
			}
			System.out.println(i);
		}
	}
public static void main(String args[]) {
	BicycleSpeed b1 = new BicycleSpeed();

	b1.start();
}
}
