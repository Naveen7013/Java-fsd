package Extendsimplementing;

class glasses implements Runnable {

	@Override
	public void run() {
		for(int i = 0; i<5; i++) {
			System.out.println("i "+i);
			
		}
	}
}
class shoes implements Runnable {

	@Override
	public void run() {
		for(int j=0;j<5;j++) {
			System.out.println("j "+j);
		}
		
	}
	
}
public class ImplementsRunnableInterfaceExample {
public static void main(String[] args) {
	Runnable r1 = new glasses();
	Thread t1 = new Thread(r1);
	Runnable r2 = new shoes();
	Thread t2 = new Thread(r2);
	t1.start();
	t2.start();
}
}
