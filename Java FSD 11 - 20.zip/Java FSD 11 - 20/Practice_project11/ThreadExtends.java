package Extendsimplementing;

class lava extends Thread {
	
	@Override
	public void run() {
		int a = 5;
		int b = 3;
		int c = a*b;
			System.out.println("The value of c is "+c);
		}
	}


class floods extends Thread {

	@Override
	public void run() {
		for(int b=1;b<=5;b++) {
			System.out.println("hello "+b);
		}
	}
	
}
public class nature {
	public static void main(String[] args) {
		lava l1=new lava();
		l1.start();
		floods f1 = new floods();
		f1.start();
	}
}