package sync;
class Counter {
    private int count = 50;

    public synchronized void increment() {
        System.out.println("Decrementing: " + count);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted.");
        }
        count--;
        System.out.println("Decrementing: " + count);
    }
}

class IncrementThread extends Thread {
    private Counter counter;

    public IncrementThread(Counter counter) {
        this.counter = counter;
    }

    @Override
    public void run() {
        synchronized (counter) {
            counter.increment();
        }
    }
}

public class SynchronizationExample2 {
    public static void main(String[] args) {
        Counter sharedCounter = new Counter();

        IncrementThread thread1 = new IncrementThread(sharedCounter);
        IncrementThread thread2 = new IncrementThread(sharedCounter);

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
    }
}
