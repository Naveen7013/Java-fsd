package tryandcatch;

public class trycatch {
    public static void main(String args[]) {
        int n1 = 5, n2 = 10, n3 = 0; // Initialize n3 to some default value

        try {
            n3 = n1 + n2;
        } catch (ArithmeticException e) {
            System.out.println("display if it is negative value");
        } finally {
            System.out.println("The result of addition is: " + n3);
        }
    }
}

