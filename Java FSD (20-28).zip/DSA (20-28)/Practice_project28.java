package Arrays;

import java.util.LinkedList;

public class queue {
	public static void main(String[] args)
	{
		LinkedList<String>movienames = new LinkedList<>();
		movienames.add("salaar");
		movienames.add("Animal");
		movienames.add("ArjunReddy");
		movienames.add("Dhruva");
		movienames.add("RRR");
		movienames.add("Saaho");
		movienames.add("RadheShyam");
		System.out.println("queue is : "+movienames);
		System.out.println("head of the queue :"+movienames.peek());
		movienames.remove();
		System.out.println("After removing Head of Queue : " + movienames);
		System.out.println("Size of Queue : " + movienames.size());

		
		
	}

}
