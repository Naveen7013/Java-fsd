package Arrays;
import java.util.Arrays;

class ArrayRotation {
	public void main(int[] arr) {
		int n = arr.length;
		int m = arr[0];
		for(int i = 0;i<n;i++) {
			arr[i] = arr[i - 1];
        }

        arr[0] = m;
    }
public static void rightRotate(int[] arr) {
	int a = 0;
	for(int i=0;i < a;i++) {
		rightRotate(arr);
	}
}
public static void main(String args[]) {
	int[] arr = {22,33,44,55,66,77,88};
	int a = 2;
	System.out.println("Original Array: " + Arrays.toString(arr));

	rightRotate(arr);

    System.out.println("Array after right rotation by " + a + " positions: " + Arrays.toString(arr));
}
}



