package Arrays;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    // Function to insert a new element in a sorted circular linked list
    public void insertSorted(int newData) {
        Node newNode = new Node(newData);

        // If the list is empty, make the new node the head and point to itself
        if (head == null) {
            head = newNode;
            head.next = head;
            return;
        }

        Node current = head;
        Node prev = null;

        // Traverse the list to find the correct position to insert the new node
        do {
            prev = current;
            current = current.next;
        } while (current != head && current.data < newData);

        // Insert the new node at the correct position
        prev.next = newNode;
        newNode.next = current;
    }

    // Function to print the circular linked list
    public void printList() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class CircularLinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList a1 = new SortedCircularLinkedList();

        a1.insertSorted(2);
        a1.insertSorted(6);
        a1.insertSorted(8);
        a1.insertSorted(16);

        // Print the original circular linked list
        System.out.println("Original sorted circular linked list:");
        a1.printList();

        // Insert a new element into the sorted circular linked list
        int newElement = 5;
        a1.insertSorted(newElement);

        // Print the circular linked list after insertion
        System.out.println("Sorted circular linked list after inserting " + newElement + ":");
        a1.printList();
    }
}
