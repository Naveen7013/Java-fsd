package Arrays;

import java.util.EmptyStackException;

public class GenericStack<T> {
    private static final int DEFAULT_CAPACITY = 10;
    private Object[] array;
    private int top;

    public GenericStack() {
        this(DEFAULT_CAPACITY);
    }

    public GenericStack(int capacity) {
        this.array = new Object[capacity];
        this.top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == array.length - 1;
    }

    public void push(T element) {
        if (isFull()) {
            System.out.println("Stack Overflow");
        } else {
            array[++top] = element;
            System.out.println(element + " pushed into stack");
        }
    }

    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        } else {
            @SuppressWarnings("unchecked")
            T poppedElement = (T) array[top--];
            System.out.println(poppedElement + " popped from stack");
            return poppedElement;
        }
    }

    public static void main(String[] args) {
        GenericStack<Integer> stack = new GenericStack<>();

        stack.push(11);
        stack.push(22);
        stack.push(33);

        System.out.println(stack.pop() + " Popped from stack");
    }
}
