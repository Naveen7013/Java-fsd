package Arrays;
class TwoMatrix {
    public static void main(String args[]) {
        int a[][] = {
                {11, 22, 33},
                {1, 2, 3}
        };
        int b[][] = {
                {44, 55},
                {4, 5},
                {8, 9}
        };
        int sum = 0;
        int c[][] = new int[2][2];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 3; k++) {
                    sum = sum + a[i][k] * b[k][j];
                }
                c[i][j] = sum;
                sum = 0;
            }
        }
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(c[i][j] + "  ");
            }
            System.out.println();
        }
    }
}
