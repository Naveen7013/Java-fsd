package Arrays;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public void deleteNode(int key) {
        Node temp = head;
        Node prev = null;

        // If the key is present at the head
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        // Search for the key to delete
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // If the key is not present
        if (temp == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Unlink the node from the linked list
        prev.next = temp.next;
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteLinkedList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        LinkedList linkedList = new LinkedList();

       
        System.out.print("Enter the number of elements in the linked list: ");
        int n = scanner.nextInt();

        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            int data = scanner.nextInt();
            Node newNode = new Node(data);

            // Add the new node to the linked list
            if (linkedList.head == null) {
                linkedList.head = newNode;
            } else {
                Node last = linkedList.head;
                while (last.next != null) {
                    last = last.next;
                }
                last.next = newNode;
            }
        }

        System.out.println("Original linked list:");
        linkedList.printList();

        System.out.print("Enter the key to delete: ");
        int keyToDelete = scanner.nextInt();

        linkedList.deleteNode(keyToDelete);

        System.out.println("Linked list after deleting node with key " + keyToDelete + ":");
        linkedList.printList();

        scanner.close();
    }
}
