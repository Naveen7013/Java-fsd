package Arrays;


import java.util.Arrays;

public class FourthSmallestElement {
    public static int findFourthSmallest(int[] arr) {
        if (arr == null || arr.length < 4) {
            System.out.println("The array should have at least 4 elements.");
            return -1; 
        }

        Arrays.sort(arr); 

        return arr[3]; //choosing 4th smallest in the array 
    }

    public static void main(String[] args) 
    {
        int[] unsortedArray = {11, 22, 33, 44, 55,66, 77, 88, 99};
        int fourthSmallest = findFourthSmallest(unsortedArray);

        if (fourthSmallest != -1) {
            System.out.println("The fourth smallest element is: " + fourthSmallest);
        }
    }
}
