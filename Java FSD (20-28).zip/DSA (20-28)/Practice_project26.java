package Arrays;

import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;

public class traverse {
        public static void main(String[] args)
        {
        	List names = new ArrayList();
        	names.add("Ramcharan");
        	names.add("MahesBabu");
        	names.add("AlluArjun");
        	names.add("Prabhas");
        	System.out.println(names); 
        	ListIterator li = names.listIterator();
        	System.out.println("forward direction");
        	while(li.hasNext()) {
        		Object obj = li.next();
        		System.out.println(obj);
        }
        	System.out.println("\nbackward direction");
        	while(li.hasPrevious()) {
        		Object obj = li.previous();
        		System.out.println(obj);
}
        }
}
