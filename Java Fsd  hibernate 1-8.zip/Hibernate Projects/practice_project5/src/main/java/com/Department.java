package com;
import java.util.List;
import java.util.Set;
import java.util.Map;

public class Department {
    private int id;
    private String name;
    private List<Employee> employeesList;
    private Set<Employee> employeesSet;
    private List<Employee> employeesBag; // Using List for Bag (similar to Set but allows duplicates)
    private Map<String, Employee> employeesMap;

    // Constructors, getters, and setters

    public Department() {
    }

    public Department(int id, String name, List<Employee> employeesList,
                      Set<Employee> employeesSet, List<Employee> employeesBag,
                      Map<String, Employee> employeesMap) {
        this.id = id;
        this.name = name;
        this.employeesList = employeesList;
        this.employeesSet = employeesSet;
        this.employeesBag = employeesBag;
        this.employeesMap = employeesMap;
    }

    // Other methods if needed

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Employee> getEmployeesList() {
        return employeesList;
    }

    public void setEmployeesList(List<Employee> employeesList) {
        this.employeesList = employeesList;
    }

    public Set<Employee> getEmployeesSet() {
        return employeesSet;
    }

    public void setEmployeesSet(Set<Employee> employeesSet) {
        this.employeesSet = employeesSet;
    }

    public List<Employee> getEmployeesBag() {
        return employeesBag;
    }

    public void setEmployeesBag(List<Employee> employeesBag) {
        this.employeesBag = employeesBag;
    }

    public Map<String, Employee> getEmployeesMap() {
        return employeesMap;
    }

    public void setEmployeesMap(Map<String, Employee> employeesMap) {
        this.employeesMap = employeesMap;
    }
}
