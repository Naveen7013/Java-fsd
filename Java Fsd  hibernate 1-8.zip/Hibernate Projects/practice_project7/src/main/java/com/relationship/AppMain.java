package com.relationship;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class AppMain {

    public static void main(String[] args) {
        SessionFactory factory = HibernateUtil.getSessionFactory();

        Address ad = new Address();
        ad.setId(10);
        ad.setAddress("Khansaar");

        EmpDtls e = new EmpDtls();
        e.setId(1);
        e.setName("Deva");
        e.setAddress(ad);

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

       // Commented out the saving part
        session.save(ad);
        session.save(e);

        EmpDtls emp = (EmpDtls) session.get(EmpDtls.class, 1);
        if (emp != null) {
            System.out.println(emp.getName());
            // Note: The following line was duplicated, so I removed one of them.
            // System.out.println(emp.getName());
            System.out.println(emp.getAddress().getAddress());
        } else {
            System.out.println("Employee not found with ID 1");
        }

        tx.commit();

        session.close();

        System.out.println("Operation Success");
        factory.close();
    }
}
