package fsdp;



class places {                                     // place is outerclass
	private String welcome_message = "Habibi Come to Dubai";
	public void displayouter() {
		System.out.println("Dubai says : "+welcome_message);
	}
	class favspot{
		public void displayinner() {
			System.out.println("Dubai not says : "+welcome_message);
		}
	}

	

	public static void main(String[] args) {
		places p1 = new places();
		p1.displayouter();
		places.favspot f1 = p1.new favspot();
		f1.displayinner();

	}
	
	
	//anonymous inner class
	abstract class Sports {
	    public abstract void display();
	}

	public class Main {
	    public static void main(String[] args) {
	        Sports s1 = new Sports() {
	            public void display() {
	                System.out.println("Under Dhoni captaincy");
	            }
	        };

	        s1.display();
	    }
	}
	

