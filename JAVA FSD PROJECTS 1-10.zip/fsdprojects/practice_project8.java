package fsdprojects;

public class Strings {

	public static void main(String[] args) {
		//methods of strings
		System.out.println("Salaar is coming, Get ready");
		
		String n1=new String("Money heist is the best web series in Netfilx");
		System.out.println(n1.length());

		//substring
		String singer=new String("Louis Fonsi");
		System.out.println(singer.substring(6));

		//String Comparison
		String s1="RamCharan";
		String s2="Upasana";
		System.out.println(s1.compareTo(s2));

		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());

		//toLowerCase
		String case1="INDIA";
		System.out.println(case1.toLowerCase());
		
		//replace
		String rep1="TEXAD";
		String replace=rep1.replace('D', 'S');
		System.out.println(replace);

		//equals
		String x="enjoy in goa";
		String y="enjoy in goa";
		System.out.println(x.equals(y));
 
		System.out.println("\n");
		System.out.println("Animal is coming");
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("Ranbir is the hero!");
		s.append("Sandeep Reddy Vanga is the director");
		System.out.println(s);

		//insert method
		s.insert(0, 'w');
		System.out.println(s);

		//replace method
		StringBuffer me1=new StringBuffer("Rocket");
		me1.replace(0, 2, "Rc1");
		System.out.println(me1);

		//delete method
		me1.delete(0, 1);
		System.out.println(me1);
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Making people Happy");
		StringBuilder n11=new StringBuilder("Keep");
		n11.append("Smiling");
		System.out.println(n11);

		System.out.println(n11.delete(0, 4));

		System.out.println(n11.insert(1, "just"));

		System.out.println(n11.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Not all the beautiful women in acting some are in teaching too");
		
		String str = "Hola"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer a1 = new StringBuffer(str); 
        a1.reverse(); 
        System.out.println("Keep Playing");
        System.out.println(a1); 
          
        // conversion from String object to StringBuilder 
        StringBuilder  con1= new StringBuilder(str); 
        con1.append("paris"); 
        System.out.println("keep learning");
        System.out.println(con1);              		
	}
}


