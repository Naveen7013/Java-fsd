package fsdprojects;

public class typecasting {

	public static void main(String[] args) {
		//Implicit Conversion
		//Starting with the integer value
		System.out.println("Implicit Conversion :");
		
		int B = 14;
		System.out.println("The integer value of B : "+B);
		
		//Converting into float
		float f = B;
		System.out.println("The float value of f : "+f);
		
		//Converting into double
		double d = B;
		System.out.println("The double value of d : "+d);
		
		//Converting into long
		long l = B;
		System.out.println("The Long value of l : "+l);
		
		//Converting into character
		char c = 'B';
		int e = 'c';
		System.out.println("The value of " +c+ " is : "+e);
		
		
		System.out.println("\n");
		
		//Explicit Conversion
		System.out.println("Explicit Conversion :");
		
		//Starting with the integer value
		int number = 25;
		System.out.println("he integer value of number : "+number);
		
		//Changing into double 
		double data = (int)number;
		System.out.println("The double value of data : "+data);
		
		//Changing into float
		float f1 = (float)data;
		System.out.println("The float value of f1 : "+f1);
		
		long l1 = (long)f1;
		System.out.println("The long value of l1 : "+l1);
		
		
	}

}
