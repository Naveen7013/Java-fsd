package fsdprojects;

//method demo
class practice_project3{
	public int add(int m, int n) {
		int p=m+n;
		return p;
		//System.out.println("The addition is : "+z);
		
	}
public static void main(String args[]) {
	practice_project3 a1 = new practice_project3();
	int sum = a1.add(12, 13);
	System.out.println("The addition is : "+sum);
}
}



//call by value
class playingwithnumbers{
	static int num = 120;
	public int numbers(int num) {
		 num = num + 100;
		 return num;
	}
public static void main(String args[]) {
	playingwithnumbers pn1 = new playingwithnumbers();
	System.out.println("before addind : "+num);
	pn1.numbers(130);
	System.out.println("after addind : "+num);
	
	}
}




// method overloading
class numbers{
	public void arithmetic(int a,int b) {
		System.out.println("addition is "+(a+b));
	}
	public void arithmetic(int a,int b,int c) {
		System.out.println("subtraction of "+(a-b-c));
	}
	public void arithmetic(int a,int b,int c,int d) {
		System.out.println("multiplication is "+(a*b*c*d));
	}
public static void main(String args[]) {
	numbers n1 = new numbers();
    n1.arithmetic(1, 2, 3, 4);
    n1.arithmetic(1, 3);
   // System.out.println("the multiplication is : "+mul);
    
}
}