package fsdprojects;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
public class maps {

	public static void main(String[] args) {
		
		//HashMap
		HashMap<String, Double> SF = new HashMap<String, Double>();
		SF.put("pizza",240.22);
		SF.put("coffee",120.23);
		SF.put("icecream",80.45);
		System.out.println("\nThe elements of HashMap are");
		for(Map.Entry<String, Double> entry : SF.entrySet()) {
			System.out.println(entry.getKey() + " " +  entry.getValue());
		}
		
	
				//HashTable
				Hashtable<String, Integer> HT = new Hashtable<String, Integer>();
				HT.put("spirit",20);
				HT.put("redbull",100);
				HT.put("cocacola",80);
				System.out.println("\nThe elements of HashTable are");
				for(Entry<String, Integer> entry : HT.entrySet()) {
					System.out.println(entry.getKey() + " " +  entry.getValue());
				}
				
			  //TreeMap
				TreeMap<Double, String> TM = new TreeMap<Double, String>();
				TM.put(14.0,"Ram");
				TM.put(33.00,"Arjun");
				TM.put(45.00,"rohit");
				System.out.println("\nThe elements of TreeMap are");
				for(Map.Entry I:TM.entrySet()) {
					System.out.println(I.getKey()+" "+I.getValue());
					
				}
				
				
				
				
			}
	
	

		
}


		



