package sample;

class person   {

	public static void main(String[] args) {
		//single dimensional
		String[] names = new String[4];
		names[0] = "cherry";
		names[1] = "Arjun";
		names[2] = "Akhil";
		names[3] = "Nitin";
		System.out.println("The one dimensional array");
		for(int i = 0;i<names.length;i++) {
			System.out.println(names[i] + " ");
		}
		
		//Multi dimensional
		double[][] mul = {
				{12.8,13.8,14.8},
				{11.8,10.8,9.8}};
		System.out.println("\n");
		System.out.println("the length of the array: "+mul.length);
		}
		              
				{
			
		}
		}


