package sample;

class privat
{ 
   private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 

public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		privat  obj = new privat(); 
        //trying to access private method of another class 
        //obj.display();

	}
}

