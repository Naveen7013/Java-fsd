package fsdprojects;

class car {
	String name;
	int maxspeed;
	public void infocar() {
		System.out.println("The car information");
	}
    public static void main(String[] args) {
        // Create an instance of Car
        car c1 = new car();

        c1.name = "Nexon";

        c1.maxspeed = 250;
        
        c1.infocar();
        
    }
}
