package sample;

import sample2.modifier1;

public class modifier {

	protected void display() 
    { 
        System.out.println("hello protected access specifier"); 
    } 
	public class modifier1 extends modifier {

		public static void main(String[] args) {
			modifier obj = new modifier ();   
		       obj.display();  
		}

	}
}
