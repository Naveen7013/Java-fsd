package fsdprojects;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Vector;
import java.util.LinkedHashSet;

//Array List
public class Arraylist {
	

	private static final String HashSet = null;

	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String> brandedclothes = new ArrayList<String>();
		brandedclothes.add("AmericanEagle");
		brandedclothes.add("Nordstrom");
		brandedclothes.add("DillardsDropship");
		brandedclothes.add("Evereve Dropship");
		System.out.println(brandedclothes);
		
		
		
		//Creating Vector
		System.out.println("\n");
		System.out.println("Creating Vector");
		Vector <String> brandedwatches = new Vector();
		brandedwatches.add("RichardMille");
		brandedwatches.add("Rolex");
		brandedwatches.add("FastTrack");
		System.out.println(brandedwatches);
		
		
		//HashSet
		System.out.println("\n");
		System.out.println("HashSet");
		HashSet <String> coffeeshop = new HashSet<String>();
		coffeeshop.add("Starbucks");
		coffeeshop.add("Barista");
		coffeeshop.add("coffeebean");
		System.out.println(coffeeshop);
		
		
		//Creating Linkedhashset
		System.out.println("\n");
		System.out.println("LinkedHashSet");
		HashSet <String> coffeeshop1 = new HashSet<String>();
		coffeeshop1.add("Starbucks");
		coffeeshop1.add("Barista");
		coffeeshop1.add("coffeebean");
		System.out.println(coffeeshop1);
	}
	

}




