package sample;
import java.util.regex.*;


public class regularexpression {

public static void main(String[] args) {

	String pattern = "[a-zA-Z1-9]+";
	String check = "All are doing good and they will get a bonus of 40000";
	Pattern p = Pattern.compile(pattern);
	Matcher c = p.matcher(check);
	
	while (c.find())
      	System.out.println( check.substring( c.start(), c.end() ) );
	}
}
