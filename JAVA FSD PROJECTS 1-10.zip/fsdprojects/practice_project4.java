package fsdprojects;

//Default Constructor

class practice_project4{
	String name;
	int age;
	
	public void practice_project4() {
		System.out.println("The actor name is :"+name);
		System.out.println("The actor age is :"+age);
		
	}
	
public static void main(String[] args) {
		practice_project4 h1 = new practice_project4();
		String info = h1.name = "Ramcharan";
		int info1 =h1.age = 34;
		System.out.println("the actor name : "+info);
		System.out.println("the actor age : "+info1);
		
		practice_project4 h2 = new practice_project4();
		h2.name = "prabhas";
		h2.age = 42;
		h2.practice_project4();

	}

}



//Parameterized constructor

class worldcup{
	String winningteam;
	String bestplayer;
	int totalwons;
	
	public void worldcup(String winningteam,String bestplayer,int totalwons) {
		this.winningteam = winningteam;
		this.bestplayer = bestplayer;
		this.totalwons = totalwons;
	}
	public void show() {
		System.out.println("The most winning team : "+winningteam);
		System.out.println("The best player in team : "+bestplayer);
		System.out.println("The total won by team : "+totalwons);
		
	}
	
		
public static void main(String args[]) {
	worldcup w1 = new worldcup();
	w1.worldcup("Austraila","maxwell",6);
	worldcup w2 = new worldcup();
	w2.worldcup("India","Virat",2);
	w1.show();
	w2.show();
	
}
}
