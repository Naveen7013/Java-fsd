package Searching;

import java.util.Scanner;

public class Linear {

    public static void main(String[] args) {
        int arr[] = {10, 20, 30, 40, 50, 60, 70, 80};
        boolean flag = false;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element you want to search:");
        int searchElement = sc.nextInt();
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == searchElement) {
                System.out.println("The element found at index " + i);
                flag = true;
                break;
            }
        }

        if (!flag) {
            System.out.println("Element not found");
        }
    }
}
