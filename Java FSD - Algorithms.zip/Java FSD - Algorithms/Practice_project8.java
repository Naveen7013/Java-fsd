package Sorting;
public class QuickSort {

    public static void main(String[] args) {
        int[] array = {77, 66, 55, 44, 33, 22, 11, 88};

        System.out.println("Before Sorting:");
        printArray(array);

        quickSort(array, 0, array.length - 1);

        System.out.println("\nAfter Sorting:");
        printArray(array);
    }

    
    public static void quickSort(int[] array, int l, int h) {
        if (l < h) {
            
            int partitionIndex = partition(array, l, h);

            //
            quickSort(array, l, partitionIndex - 1);
            quickSort(array, partitionIndex + 1, h);
        }
    }

    
    public static int partition(int[] array, int l, int h) {
        int pivot = array[h];
        int i = l - 1;

        for (int j = l; j < h; j++) {
            
            if (array[j] <= pivot) {
                i++;

                
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        
        int temp = array[i + 1];
        array[i + 1] = array[h];
        array[h] = temp;

        
        return i + 1;
    }

   
    public static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
