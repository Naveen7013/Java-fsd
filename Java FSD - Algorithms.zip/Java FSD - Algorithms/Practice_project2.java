package Searching;

public class BinarySearch {

    public static void main(String[] args) {
        int arr[] = {5, 2, 4, 8, 1, 9, 3};
        int n = arr.length;
        int data = 9;
        int result = binarysearch(arr, n, data);

        if (result == -1) {
            System.out.println("Element not present in the array");
        } else {
            System.out.println("Element found at index " + result);
        }
    }

    private static int binarysearch(int[] arr, int n, int data) {
        int l = 0;
        int r = n - 1;
        while (l <= r) {
            int mid = (l + r) / 2;

            if (arr[mid] == data) 
            {
                return mid;
            }
            else if (arr[mid] < data) 
            {
                l = mid + 1;
            } 
            else 
            {
                r = mid - 1;
            }
        }

        return -1;
    }
}
