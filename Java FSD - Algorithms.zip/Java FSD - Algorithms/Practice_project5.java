package Sorting;

import java.util.*;

public class bubble {

	public static void main(String[] args) {
		int arr[] = {9,25,6,3,2,55,1};
		int n = arr.length;
		int temp = 0;
		System.out.println("Before sorting");
		for(int num : arr)
		{
			System.out.println(num + " ");
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		System.out.println("after sorting");
		for(int num : arr)
		{
			System.out.println(num + " ");
		}
}
}
