package Sorting;

public class Selection {

    public static void main(String[] args) {
        int arr[] = {9, 3, 5, 2, 4, 1, 6};
        int n = arr.length;
        int temp = 0;
        System.out.println("before sorting");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();  // Add a new line after printing the initial array

        for (int i = 0; i < n - 1; i++) {
            int min = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[min])
                    min = j;
            }
            temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }

        System.out.println("after sorting");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
