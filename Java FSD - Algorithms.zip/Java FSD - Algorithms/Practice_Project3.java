package Searching;

import java.util.Arrays;

public class ExponentialSearch {

	public static void main(String[] args) {
		int arr[] = {4,7,9,22,1,44,54,17};
		int n = arr.length;
		int data = 44;
		int result = exponentialSearch(arr,n,data);
		if(result < 0)
		{
			System.out.println("Element not found");
		}
		else
		{
			System.out.println("Element found at the : "+result);
		}

	}

	private static int exponentialSearch(int[] arr, int n, int data) {
		if(arr[0]==data)
		{
			return 0;
		}
		int i = 1;
		while(i<n && arr[i]<=data)
		{
			i=i*2;
		}
		return Arrays.binarySearch(arr, i / 2, Math.min(i, n), data);
		
	}

}
