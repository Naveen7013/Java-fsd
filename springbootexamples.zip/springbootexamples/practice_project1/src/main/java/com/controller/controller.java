package com.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.errors.Error;

import com.customexceptions.EmailValidationException;
import com.customexceptions.FirstNameValidationException;
import com.entity.User;

@RestController
public class controller {
	
	@PostMapping("/user")
	public User addUser(@RequestBody User user) {
		if(!user.getEmail().contains("@")) {
			throw new EmailValidationException("Not a valid Email :: "+user.getEmail());
			
		}
		if(user.getFname().contains("!")) {
			throw new FirstNameValidationException("Not a valid name :: "+user.getFname());
		}
		
		return user;
		
	}
	@ExceptionHandler(value = EmailValidationException.class)
    public ResponseEntity<Error> emailValidation(EmailValidationException exception) {
        Error error=new Error(1000,exception.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	    }
	 
}
