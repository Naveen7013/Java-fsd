package com.example.fileuploading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileuploadingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileuploadingApplication.class, args);
	}

}
