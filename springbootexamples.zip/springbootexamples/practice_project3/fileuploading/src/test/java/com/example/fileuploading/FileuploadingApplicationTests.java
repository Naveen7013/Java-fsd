package com.example.fileuploading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileuploadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
