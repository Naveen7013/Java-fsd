package com.browser.sampleHttps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleHttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
