package com.browser.sampleHttps.viewmapping;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class viewmapping implements WebMvcConfigurer {
	
	@Override
	public void addViewControllers(ViewControllerRegistry vcr) {
		vcr.addViewController("/").setViewName("home");
		vcr.addViewController("/home").setViewName("home");
		vcr.addViewController("/greetings").setViewName("greetings");
	}

}
