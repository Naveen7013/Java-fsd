package com.browser.sampleHttps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleHttpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleHttpsApplication.class, args);
	}

}
