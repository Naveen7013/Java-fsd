package com.springrest.springrest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.springrest.springrest.entities.Movies;

@Service
public class Movieserviceimpl implements Movieservice {
	
	List<Movies> list;
	
	public Movieserviceimpl() {
		list = new ArrayList<>();
		list.add(new Movies("Salaar",400,"Prabhas"));
	}

	@Override
	public List<Movies> getMovies() {
		return list;
	}

}
