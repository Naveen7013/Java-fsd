package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entities.Movies;
import com.springrest.springrest.service.Movieservice;

@RestController
public class MyController {
	
	@Autowired
	private Movieservice movieservice;
	
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to the salaar world";
	}
	
	
	@GetMapping("/Movies")
	public List<Movies> getMovies() 
	{
		return this.movieservice.getMovies();
		
		
	}

}
