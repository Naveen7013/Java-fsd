package com.springrest.springrest.service;

import java.util.List;

import com.springrest.springrest.entities.Movies;

public interface Movieservice {
	
	public List<Movies> getMovies();
	

}
