package com.springrest.springrest.entities;

public class Movies {
	private String name;
	private int Budget;
	private String hero;
	public Movies(String name, int budget, String hero) {
		super();
		this.name = name;
		Budget = budget;
		this.hero = hero;
	}
	public Movies() {
		super();
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBudget() {
		return Budget;
	}
	public void setBudget(int budget) {
		Budget = budget;
	}
	public String getHero() {
		return hero;
	}
	public void setHero(String hero) {
		this.hero = hero;
	}
	@Override
	public String toString() {
		return "Movies [name=" + name + ", Budget=" + Budget + ", hero=" + hero + "]";
	}
	
	

}
